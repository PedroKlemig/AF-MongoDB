const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

const MONGO_URL =
  process.env.MONGO_URL ||
  'mongodb+srv://123:321@cluster0.l2dfevv.mongodb.net/?appName=Cluster0';
mongoose
  .connect(MONGO_URL)
  .then(() => console.log(' MongoDB conectado com sucesso'))
  .catch((err) => console.error(' Erro ao conectar no MongoDB:', err));


const movimentacaoSchema = new mongoose.Schema(
  {
    tipo: { type: String, enum: ['receita', 'despesa'], required: true },
    categoria: { type: String, required: true },
    descricao: { type: String, required: true },
    valor: { type: Number, required: true },
    data: { type: Date, required: true },
  },
  {
    timestamps: true,
  }
);

const Movimentacao = mongoose.model('Movimentacao', movimentacaoSchema);


app.get('/movimentacoes', async (req, res) => {
  try {
    const itens = await Movimentacao.find().sort({ data: -1 });
    res.json(itens);
  } catch (err) {
    console.error(err);
    res.status(500).json({ erro: 'Erro ao listar movimentações' });
  }
});


app.post('/movimentacoes', async (req, res) => {
  try {
    const mov = new Movimentacao(req.body);
    const salvo = await mov.save();
    res.status(201).json(salvo);
  } catch (err) {
    console.error(err);
    res.status(400).json({ erro: 'Erro ao salvar movimentação' });
  }
});


app.delete('/movimentacoes/:id', async (req, res) => {
  try {
    await Movimentacao.findByIdAndDelete(req.params.id);
    res.status(204).end();
  } catch (err) {
    console.error(err);
    res.status(400).json({ erro: 'Erro ao excluir movimentação' });
  }
});


const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
  console.log(`🚀 API ouvindo em http://localhost:${PORT}`);
});


