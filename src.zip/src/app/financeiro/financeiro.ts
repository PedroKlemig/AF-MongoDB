import { Component, OnInit, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { NgIf, NgFor, DatePipe, CurrencyPipe } from '@angular/common';
import { MovimentacoesService, Movimentacao } from '../movimentacoes-service';


@Component({
  selector: 'app-financeiro',
  standalone: true,
  imports: [FormsModule, DatePipe, CurrencyPipe],
  templateUrl: './financeiro.html',
  styleUrl: './financeiro.css'
})
export class Financeiro implements OnInit {


  private movimentacoesApi = inject(MovimentacoesService);


  movimentacoesRegistradas: Movimentacao[] = [];
  estaCarregando = false;
  estaSalvando = false;
  mensagemErro = '';


  tipoMovimentacao: 'receita' | 'despesa' = 'receita';
  categoriaMovimentacao = '';
  descricaoMovimentacao = '';
  valorMovimentacao: number | null = null;
  dataMovimentacao = '';

  ngOnInit(): void {
    this.carregarMovimentacoes(); 
  }

  get saldo(): number {

    return this.movimentacoesRegistradas.reduce(
      (total, movimentacao) =>
        movimentacao.tipo === 'receita' ? total + movimentacao.valor : total - movimentacao.valor,
      0
    );
  }

  carregarMovimentacoes(): void {
    this.estaCarregando = true;
    this.mensagemErro = '';

    this.movimentacoesApi.listar().subscribe({
      next: listaRecebida => {
        this.movimentacoesRegistradas = listaRecebida; 
        this.estaCarregando = false;
      },
      error: () => {
        this.mensagemErro = 'Erro ao carregar movimentações.';
        this.estaCarregando = false;
      }
    });
  }

  adicionarMovimentacao(): void {
    if (
      !this.categoriaMovimentacao ||
      !this.descricaoMovimentacao ||
      this.valorMovimentacao == null ||
      !this.dataMovimentacao
    ) {
      return;
    }

    this.estaSalvando = true;
    this.mensagemErro = '';

    

    const novaMovimentacao: Movimentacao = {
      tipo: this.tipoMovimentacao,
      categoria: this.categoriaMovimentacao,
      descricao: this.descricaoMovimentacao,
      valor: Number(this.valorMovimentacao),
      data: this.dataMovimentacao
    };

    

    this.movimentacoesApi.criar(novaMovimentacao).subscribe({
      next: movimentacaoCriada => {
        this.movimentacoesRegistradas.push(movimentacaoCriada); 
        this.limparFormulario(); 
        this.estaSalvando = false;
      },
      error: () => {
        this.mensagemErro = 'Erro ao salvar movimentação.';
        this.estaSalvando = false;
      }
    });
  }

  removerMovimentacao(movimentacaoParaRemover: Movimentacao): void {
    // Só exclui se tiver ID
    if (!movimentacaoParaRemover._id) return;

    this.movimentacoesApi.excluir(movimentacaoParaRemover._id).subscribe({
      next: () => {
        // Remove da lista local
        this.movimentacoesRegistradas = this.movimentacoesRegistradas.filter(
          movimentacao => movimentacao._id !== movimentacaoParaRemover._id
        );
      },
      error: () => {
        this.mensagemErro = 'Erro ao excluir movimentação.';
      }
    });
  }

  private limparFormulario(): void {
    // Reseta os campos
    this.tipoMovimentacao = 'receita';
    this.categoriaMovimentacao = '';
    this.descricaoMovimentacao = '';
    this.valorMovimentacao = null;
    this.dataMovimentacao = '';
  }
}
