// Service responsável por centralizar todas as chamadas HTTP relacionadas
// às movimentações financeiras.
import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';


// Interface que representa o formato de uma movimentação tanto
// no frontend quanto quando vem do backend.
export interface Movimentacao {
  // _id é gerado automaticamente pelo MongoDB
  _id?: string;
  // Tipo define se é receita (entra dinheiro) ou despesa (sai dinheiro)
  tipo: 'receita' | 'despesa';
  // Categoria para agrupar (ex.: casa, mercado, lazer)
  categoria: string;
  // Descrição mais detalhada da movimentação
  descricao: string;
  // Valor em reais (positivo)
  valor: number;
  // Data em formato ISO (string) que depois é convertida em Date no backend
  data: string;
}

@Injectable({
  providedIn: 'root'            // Torna o serviço disponível em toda a aplicação
})
export class MovimentacoesService {

  // HttpClient é o responsável por fazer as requisições HTTP
  private http = inject(HttpClient);

  // URL base da nossa API de movimentações
  // Se o backend mudar de porta ou caminho, basta ajustar aqui.
  private baseUrl = 'http://localhost:3000/movimentacoes';

  // Busca todas as movimentações cadastradas no backend (GET)
  listar(): Observable<Movimentacao[]> {
    return this.http.get<Movimentacao[]>(this.baseUrl);
  }

  // Cria uma nova movimentação no backend (POST)
  criar(mov: Movimentacao): Observable<Movimentacao> {
    return this.http.post<Movimentacao>(this.baseUrl, mov);
  }

  // Remove uma movimentação específica pelo seu ID (DELETE)
  excluir(id: string): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/${id}`);
  }
}
